import numpy as np
from scipy.stats import multivariate_normal
from PIL import Image

eps = 1e-6
epoches = 3

im = Image.open("image.jpg")  # RGB
# im.show()

# jpeg to numpy
im_tensor = np.array(im, dtype=np.float32)
im.close()
IM_LEN = im_tensor.shape[0] * im_tensor.shape[1]
# print(im_vec.shape) # (1466, 2200, 3)
# print(im_vec[0, 0, :]) # [107  84  16]
# print(im_vec[0, 0, 0].dtype) # float32

im_vec = np.reshape(im_tensor, (IM_LEN, 3))
# print(im_vec.shape) #(3225200, 3)

# Specify number of mixtures
K = 2
DIM = 3

# Specify priors
mu = 255 * np.random.random((K, DIM)) + 1 # np.ones((K, DIM)) * 127 # np.random.randn(K, DIM)
sigma2 = np.ones(K) * 1000 # [np.identity(DIM) * 1000 for i in range(K)]
pi = np.ones(K) / K

def post_dist(x, mu, sigma2, pi, k, dim):
    # must in vector/matrix fashion, otherwise incomputable
    weights = np.zeros((x.shape[0], k))
    for i in range(k):
        # For stability
        weights[:, i] = np.exp(np.log(pi[i]) + multivariate_normal.logpdf(x, mu[i, :], np.identity(dim) * sigma2[i]))
    return (weights.T / np.sum(weights, axis=1)).T # broadcast

def log_likelihood(x, post_dist, mu, sigma2, pi, k, dim): 
    # must in vector/matrix fashion, otherwise incomputable
    weights = np.zeros((x.shape[0], k))
    for i in range(k): 
        weights[:, i] = multivariate_normal.logpdf(x, mu[i, :], np.identity(dim) * sigma2[i]) + np.log(pi[i])
    return np.sum(post_dist * weights)

gamma = []
for epoch in range(epoches):
    # Expectation
    gamma = post_dist(im_vec, mu, sigma2, pi, K, DIM)

    # Maximization
    weights = gamma / np.sum(gamma, axis=0)
    for i in range(K): # mu and sigma2
        mu[i, :] = np.average(im_vec, axis=0, weights=weights[:, i])
        # full covariance matrix will eat up the memory, so we use diagonal matrix
        sigma2[i] = np.average(np.sum(np.square(im_vec - mu[i, :]), axis=1), axis=0, weights=weights[:, i])

    # print(mu, sigma2)

    # responsibilities: pi
    _pi = np.sum(gamma, axis=0)
    pi = _pi / np.sum(_pi)

    # print(pi)

    print("Log Likelihood after {0}: {1}".format(epoch, log_likelihood(im_vec, gamma, mu, sigma2, pi, K, DIM)))

# numpy to image
gamma = np.argmax(gamma, axis=1)
im_post_out = np.reshape(mu[gamma], im_tensor.shape)
im = Image.fromarray(np.array(im_post_out, dtype=np.uint8))
im.save('out.bmp')
im.show()